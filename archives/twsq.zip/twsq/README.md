TWSQ quantitative trading library
